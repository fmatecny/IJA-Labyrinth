Nazov: Labyrinth

Autori:
	xmatec00
	xnovak1b

Preklad: ant compile v korenovom adresari
Spustenie: ant run v korenovom adresari
Menu: zaskrtnite pocet hracov, velkost pola (pocet pokladov bude automaticky vygenerovane podla veslkosti pola)
Save: ulozi hru, pocet najdenych pokladov u hraca, aktualneho hraca na rade
Koniec: pozbierany dany pocet pokladov (do menu sa dostanete opätovnym kliknutim bud na mysi alebo klavesnici)
Pravidla: rozsirenie revizie (hrac nemoze posunut spätne ziadnny riadok s opacnej strany ako predchadzajuci posun)
	  hrac moze pocas tahu zobrat viac ako jeden poklad pokial to je mozne
	  hrac moze prejst cez stenu pokial to cesta umoznuje
	  hrac moze kedykolvek pocas svojho tahu vyuzit posun sudych radov a stlpcov (avsak nemusi tento posun vyuzit)
	  
	  
